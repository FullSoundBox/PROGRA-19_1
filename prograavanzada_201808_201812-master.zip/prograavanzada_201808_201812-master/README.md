# prograavanzada_201808_201812
Repositorio para el curso Programación Avanzada (Agosto-Diciembre, 2018) en la UPIITA del IPN.
Repositorio creado principalmente para compartir archivos de c\'odigo fuente y posiblemente otros 
tipos de archivo con los discentes del grupo 2MV3.
