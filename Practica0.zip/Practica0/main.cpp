#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    cout<<"Hola Mundo 2mv3 Programacion Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
