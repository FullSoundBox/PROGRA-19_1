/* TestEmpleado.cpp Usa la clase empleado */
#include <iostream>
using std::cout;
using std::endl;

#include "Empleado.h"

int main(){
	cout<<"El numero de empleados antes de instanciar cualquier objeto es "
	<<Empleado::getCuenta()<<endl;
	system("pause");
	return 0;
}
