/**Empleado.h - declara la clase empleado*/
#ifndef EMPLEADO_H
#define EMPLEADO_H

class Empleado{
public:
	//Constructor
	Empleado(const char *const,const char *const);
	//Destructor
	~Empleado();
	const char *getPrimerNombre()	const; //Devuelve el primer nombre
	const char *getApellidoPaterno()	const; // Devuelve el appelido paterno

	static int getCuenta(); //devuelve el numero de objetos instanciados

private:
	char *primerNombre;
	char *apellidoPaterno;

	//datos static
	static int cuenta;	//Numero de objetos instanciados
};//End class empleado

#endif /* Empleado_H*/