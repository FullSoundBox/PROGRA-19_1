/*Empleado.cpp - Resuleve los metodos de la clase Empleado */
#include <iostream>
using std::cout;
using std::endl;
#include <cstring>
using std::strlen;
using std::strcpy;

#include "Empleado.h"
int Empleado::Cuenta=0;

int Empleado::getCuenta(){
	return cuenta;
};

Empleado::Empleado(const char *const nombre, const char *const apellido){
	primerNombre=new char[strlen(nombre)+1;
	strcpy(primerNombre, nombre);
	apellidoPaterno=new char[stlen(apellido+1)];
	strcpy(apellidoPaterno,apellido);

	cuenta++�;
	cout<<"Se llamo al constructor del Empleado para"<<primerNombre<<" "
	apellidoPaterno<<endl;
}
	//el constructor designa la memoria asignada de forma dinamica
Empleado::~Empleado(){
	cout<<"Se llamo a ~Empleado() para"<<primerNombre<<" "
	delete [] primerNombre;
	delete [] apellidoPaterno;
	cuenta--;
}